import random
from game_message import *


class Bot:
    def __init__(self):
        print("Initializing your super mega duper bot")
        self.exploration_targets = {}  # Track where each spore is heading
        self.spawner_created = False
        self.stationed_spores = set()  # Track spores that reached 10+ biomass and should stay put

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        NEW STRATEGY:
        1. Spread spores across map to accumulate biomass
        2. When spore reaches 300+ biomass, convert it to spawner
        3. Find spawner with most biomass at its tile
        4. Use that spawner to produce 10-biomass spores
        """
        actions = []
        my_team: TeamInfo = game_message.world.teamInfos[game_message.yourTeamId]
        game_map = game_message.world.map
        
        # Step 1: Create initial spawner if we don't have one
        if len(my_team.spawners) == 0 and len(my_team.spores) > 0:
            actions.append(SporeCreateSpawnerAction(sporeId=my_team.spores[0].id))
            self.spawner_created = True
            return actions
        
        # Step 2: Convert spores with 100+ biomass into spawners (lowered from 300)
        spawner_positions = {(s.position.x, s.position.y) for s in my_team.spawners}
        for spore in my_team.spores:
            if spore.biomass >= 100:
                # Check if spawner already exists at this position
                if (spore.position.x, spore.position.y) not in spawner_positions:
                    if spore.biomass >= my_team.nextSpawnerCost:
                        actions.append(SporeCreateSpawnerAction(sporeId=spore.id))
                        print(f"Converting spore with {spore.biomass} biomass into spawner #{len(my_team.spawners)+1} at ({spore.position.x}, {spore.position.y})")
                        return actions  # Return immediately after creating spawner
        
        # Step 3: ALL spawners produce one 10-biomass spore per tick
        # Prioritize spawners with more biomass at their tile (they're better defended)
        if len(my_team.spawners) > 0:
            # Sort spawners by biomass at their tile location (most biomass first)
            spawners_with_biomass = []
            for spawner in my_team.spawners:
                tile_biomass = game_message.world.biomassGrid[spawner.position.y][spawner.position.x]
                spawners_with_biomass.append((spawner, tile_biomass))
            
            # Sort by biomass (descending)
            spawners_with_biomass.sort(key=lambda x: x[1], reverse=True)
            
            # Each spawner produces ONE spore per tick (game rule: one action per entity)
            for spawner, tile_biomass in spawners_with_biomass:
                # Only produce spores if tile has less than 100 biomass
                if tile_biomass < 100 and my_team.nutrients >= 20:
                    actions.append(
                        SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=int(max(my_team.nutrients * 0.5, 5)))
                    )
                    my_team.nutrients -= 5
                    print(f"Tick {game_message.tick}: Spawner at ({spawner.position.x}, {spawner.position.y}) producing spore (tile biomass: {tile_biomass})")
                elif tile_biomass >= 100:
                    print(f"Tick {game_message.tick}: Spawner at ({spawner.position.x}, {spawner.position.y}) skipped - tile has {tile_biomass} biomass (>= 100)")
        
        # Step 4: Split large spores (500+ biomass) into two smaller spores
        spores_used = set()  # Track spores that have been used for actions
        for spore in my_team.spores:
            if spore.id in spores_used:
                continue
            
            # Split spores with 500+ biomass to spread resources better
            if spore.biomass >= 500:
                split_amount = spore.biomass // 2  # Split in half
                # Pick a random direction for the moving spore
                directions = [
                    Position(x=0, y=-1),  # up
                    Position(x=0, y=1),   # down
                    Position(x=-1, y=0),  # left
                    Position(x=1, y=0)    # right
                ]
                direction = random.choice(directions)
                actions.append(SporeSplitAction(
                    sporeId=spore.id, 
                    biomassForMovingSpore=split_amount,
                    direction=direction
                ))
                spores_used.add(spore.id)
                print(f"Tick {game_message.tick}: Splitting spore {spore.id} with {spore.biomass} biomass into two ({split_amount} each)")
                # Return immediately - one action per tick per entity
                # The split spores will move on next tick
        
        # Step 5: Move ALL spores aggressively - don't station them, keep spreading!
        spawner_positions = {(s.position.x, s.position.y) for s in my_team.spawners}
        
        for spore in my_team.spores:
            if spore.id in spores_used:
                continue
            
            # Keep all spores moving to spread across the map
            # Only stop spores that have 100+ biomass (they'll become spawners)
            if spore.biomass >= 100:
                # These will become spawners in the next tick, so don't move them
                spores_used.add(spore.id)
                continue
            
            # CRITICAL: If spore is ON or very close to a spawner, force it to move away immediately!
            on_spawner = (spore.position.x, spore.position.y) in spawner_positions
            near_spawner = any(
                abs(spore.position.x - sx) <= 2 and abs(spore.position.y - sy) <= 2
                for sx, sy in spawner_positions
            )
            
            # Force new target if on/near spawner OR reached current target
            needs_new_target = (
                spore.id not in self.exploration_targets or
                on_spawner or
                near_spawner or
                (abs(spore.position.x - self.exploration_targets[spore.id].x) <= 1 and
                 abs(spore.position.y - self.exploration_targets[spore.id].y) <= 1)
            )
            
            if needs_new_target:
                target = self._get_spread_target(spore, game_map, game_message.world, my_team)
                self.exploration_targets[spore.id] = target
            else:
                target = self.exploration_targets[spore.id]
            
            actions.append(
                SporeMoveToAction(
                    sporeId=spore.id,
                    position=target
                )
            )
            spores_used.add(spore.id)
        
        return actions
    
    def _get_spread_target(self, spore: Spore, game_map: GameMap, world: GameWorld, my_team: TeamInfo) -> Position:
        """
        Get a target position with AGGRESSIVE strategy.
        Goal: Attack enemy tiles and expand territory.
        """
        best_score = -1
        best_position = Position(
            x=random.randint(0, game_map.width - 1),
            y=random.randint(0, game_map.height - 1)
        )
        
        # Get our spawner positions to avoid sending spores there
        our_spawner_positions = {(spawner.position.x, spawner.position.y) for spawner in my_team.spawners}
        
        # Sample random positions and pick the best one for attacking/spreading
        for _ in range(20):  # Increased samples for better targeting
            x = random.randint(0, game_map.width - 1)
            y = random.randint(0, game_map.height - 1)
            
            # CRITICAL: Skip tiles with our spawners - don't send biomass there!
            if (x, y) in our_spawner_positions:
                continue
            
            # Also heavily penalize tiles NEAR our spawners (within 3 tiles)
            near_our_spawner = any(
                abs(x - sx) <= 3 and abs(y - sy) <= 3
                for sx, sy in our_spawner_positions
            )
            
            nutrients = game_map.nutrientGrid[y][x]
            distance = abs(spore.position.x - x) + abs(spore.position.y - y)
            owner = world.ownershipGrid[y][x]
            tile_biomass = world.biomassGrid[y][x]
            
            # Score calculation - AGGRESSIVE strategy
            score = 0
            
            # CRITICAL: Heavily penalize positions near our spawners
            if near_our_spawner:
                score -= 500  # Make these positions very unattractive
            
            # PRIORITY 1: Attack enemy tiles (not neutral, not ours)
            if owner != spore.teamId and owner != "":
                score += 200  # Very high priority for enemy tiles
                
                # Prefer weakly defended enemy tiles (easy to conquer)
                if tile_biomass < spore.biomass:
                    score += 150  # We can win this fight!
                elif tile_biomass < spore.biomass * 1.5:
                    score += 100  # Close fight, but winnable
                else:
                    score += 50  # Tough fight, but still worth attacking
            
            # PRIORITY 2: Claim neutral territory
            elif owner != spore.teamId:
                score += 80
            
            # Prefer nutrient-rich tiles
            score += nutrients * 2  # Double weight on nutrients
            
            # Prefer positions not too far away (focus attacks)
            if distance < 15:
                score += 40
            elif distance < 25:
                score += 20
            
            # Distance penalty (don't go too far)
            score -= distance * 0.5
            
            if score > best_score:
                best_score = score
                best_position = Position(x=x, y=y)
        
        return best_position