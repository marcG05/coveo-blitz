import random
from game_message import *


class Bot:
    def __init__(self):
        print("Initializing your super mega duper bot")
        self.exploration_targets = {}  # Track where each spore is heading
        self.spawner_created = False
        self.stationed_spores = set()  # Track spores that reached 10+ biomass and should stay put

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        NEW STRATEGY:
        1. Spread spores across map to accumulate biomass
        2. When spore reaches 300+ biomass, convert it to spawner
        3. Find spawner with most biomass at its tile
        4. Use that spawner to produce 10-biomass spores
        """
        actions = []
        my_team: TeamInfo = game_message.world.teamInfos[game_message.yourTeamId]
        game_map = game_message.world.map
        
        # Step 1: Create initial spawner if we don't have one
        if len(my_team.spawners) == 0 and len(my_team.spores) > 0:
            actions.append(SporeCreateSpawnerAction(sporeId=my_team.spores[0].id))
            self.spawner_created = True
            return actions
        
        # Step 2: Convert spores with 300+ biomass into spawners
        spawner_positions = {(s.position.x, s.position.y) for s in my_team.spawners}
        for spore in my_team.spores:
            if spore.biomass >= 300:
                # Check if spawner already exists at this position
                if (spore.position.x, spore.position.y) not in spawner_positions:
                    if spore.biomass >= my_team.nextSpawnerCost:
                        actions.append(SporeCreateSpawnerAction(sporeId=spore.id))
                        print(f"Converting spore with {spore.biomass} biomass into spawner at ({spore.position.x}, {spore.position.y})")
                        return actions  # Return immediately after creating spawner
        
        # Step 3: ALL spawners produce 10-biomass spores
        # Prioritize spawners with more biomass at their tile (they're better defended)
        if len(my_team.spawners) > 0:
            # Sort spawners by biomass at their tile location (most biomass first)
            spawners_with_biomass = []
            for spawner in my_team.spawners:
                tile_biomass = game_message.world.biomassGrid[spawner.position.y][spawner.position.x]
                spawners_with_biomass.append((spawner, tile_biomass))
            
            # Sort by biomass (descending)
            spawners_with_biomass.sort(key=lambda x: x[1], reverse=True)
            
            # Each spawner produces spores if we have nutrients
            for spawner, tile_biomass in spawners_with_biomass:
                if my_team.nutrients >= 10:
                    actions.append(
                        SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=10)
                    )
                    my_team.nutrients -= 10
                    # print(f"Spawner at ({spawner.position.x}, {spawner.position.y}) with {tile_biomass} tile biomass producing spore")
        
        # Step 4: Move spores strategically - station them once they reach 50+ biomass
        for spore in my_team.spores:
            # If spore has 10+ biomass, mark it as stationed and don't move it
            if spore.biomass >= 50:
                if spore.id not in self.stationed_spores:
                    self.stationed_spores.add(spore.id)
                    print(f"Spore {spore.id} stationed with {spore.biomass} biomass at ({spore.position.x}, {spore.position.y})")
                # Don't add movement action for stationed spores
                continue
            
            # For spores under 10 biomass, spread them across the map
            # Check if spore reached its target or doesn't have one
            if spore.id not in self.exploration_targets:
                target = self._get_spread_target(spore, game_map, game_message.world, my_team)
                self.exploration_targets[spore.id] = target
            else:
                target = self.exploration_targets[spore.id]
                # If reached target, get a new one
                if abs(spore.position.x - target.x) <= 1 and abs(spore.position.y - target.y) <= 1:
                    target = self._get_spread_target(spore, game_map, game_message.world, my_team)
                    self.exploration_targets[spore.id] = target
            
            actions.append(
                SporeMoveToAction(
                    sporeId=spore.id,
                    position=target
                )
            )
        
        return actions
    
    def _get_spread_target(self, spore: Spore, game_map: GameMap, world: GameWorld, my_team: TeamInfo) -> Position:
        """
        Get a target position to maximize map coverage.
        Goal: Spread spores evenly across the entire map.
        """
        best_score = -1
        best_position = Position(
            x=random.randint(0, game_map.width - 1),
            y=random.randint(0, game_map.height - 1)
        )
        
        # Sample random positions and pick the best one for spreading
        for _ in range(15):
            x = random.randint(0, game_map.width - 1)
            y = random.randint(0, game_map.height - 1)
            
            nutrients = game_map.nutrientGrid[y][x]
            distance = abs(spore.position.x - x) + abs(spore.position.y - y)
            owner = world.ownershipGrid[y][x]
            tile_biomass = world.biomassGrid[y][x]
            
            # Score calculation - prioritize spreading and unclaimed territory
            score = 0
            
            # Heavily prioritize tiles not owned by us
            if owner != spore.teamId:
                score += 100
            
            # Prefer neutral territory
            if owner == world.map.nutrientGrid[0][0]:  # Approximate neutral check
                score += 50
            
            # Prefer tiles with low enemy biomass (easy to take)
            if owner != spore.teamId and tile_biomass < 10:
                score += 30
            
            # Prefer nutrient-rich tiles
            score += nutrients
            
            # Prefer positions far from our current position (spread out!)
            if distance > 10:
                score += 20
            
            # Slight penalty for very far distances (still want to get there eventually)
            score -= distance * 0.3
            
            if score > best_score:
                best_score = score
                best_position = Position(x=x, y=y)
        
        return best_position