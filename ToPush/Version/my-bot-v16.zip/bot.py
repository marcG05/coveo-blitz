import random
from game_message import *


class Bot:
    def __init__(self):
        print("Initializing your super mega duper bot")
        self.exploration_targets = {}  # Track where each spore is heading
        self.spawner_created = False
        self.stationed_spores = set()  # Track spores that reached 10+ biomass and should stay put

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        Strategy: Create MANY small 10 biomass spores and spread them across the map.
        Once a spore reaches 10+ biomass, it stays in place to claim territory.
        """
        actions = []
        my_team: TeamInfo = game_message.world.teamInfos[game_message.yourTeamId]
        game_map = game_message.world.map
        
        # Step 1: Create initial spawner if we don't have one
        if len(my_team.spawners) == 0 and len(my_team.spores) > 0:
            actions.append(SporeCreateSpawnerAction(sporeId=my_team.spores[0].id))
            self.spawner_created = True
        
        # Step 2: Create ONE 10 biomass spore per spawner per tick
        elif len(my_team.spawners) > 0:
            # Each spawner can only perform ONE action per tick!
            for spawner in my_team.spawners:
                if my_team.nutrients >= 10:
                    actions.append(
                        SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=10)
                    )
                    my_team.nutrients -= 10
                    
        
        # Step 3: Move spores strategically - station them once they reach 10+ biomass
        for spore in my_team.spores:
            # If spore has 10+ biomass, mark it as stationed and don't move it
            if spore.biomass >= 30:
                if spore.id not in self.stationed_spores:
                    self.stationed_spores.add(spore.id)
                    print(f"Spore {spore.id} stationed with {spore.biomass} biomass at ({spore.position.x}, {spore.position.y})")
                # Don't add movement action for stationed spores
                continue
            
            # For spores under 10 biomass, spread them across the map
            # Check if spore reached its target or doesn't have one
            if spore.id not in self.exploration_targets:
                target = self._get_spread_target(spore, game_map, game_message.world, my_team)
                self.exploration_targets[spore.id] = target
            
            else:
                target = self.exploration_targets[spore.id]
                # If reached target, get a new one
                if abs(spore.position.x - target.x) <= 1 and abs(spore.position.y - target.y) <= 1:
                    target = self._get_spread_target(spore, game_map, game_message.world, my_team)
                    self.exploration_targets[spore.id] = target
            
            actions.append(
                SporeMoveToAction(
                    sporeId=spore.id,
                    position=target
                )
            )
        
        return actions
    
    def _get_spread_target(self, spore: Spore, game_map: GameMap, world: GameWorld, my_team: TeamInfo) -> Position:
        """
        Get a target position to maximize map coverage.
        Goal: Spread spores evenly across the entire map.
        """
        best_score = -1
        best_position = Position(
            x=random.randint(0, game_map.width - 1),
            y=random.randint(0, game_map.height - 1)
        )
        
        # Sample random positions and pick the best one for spreading
        for _ in range(15):
            x = random.randint(0, game_map.width - 1)
            y = random.randint(0, game_map.height - 1)
            
            nutrients = game_map.nutrientGrid[y][x]
            distance = abs(spore.position.x - x) + abs(spore.position.y - y)
            owner = world.ownershipGrid[y][x]
            tile_biomass = world.biomassGrid[y][x]
            
            # Score calculation - prioritize spreading and unclaimed territory
            score = 0
            
            # Heavily prioritize tiles not owned by us
            if owner != spore.teamId:
                score += 100
            
            # Prefer neutral territory
            if owner == world.map.nutrientGrid[0][0]:  # Approximate neutral check
                score += 50
            
            # Prefer tiles with low enemy biomass (easy to take)
            if owner != spore.teamId and tile_biomass < 10:
                score += 30
            
            # Prefer nutrient-rich tiles
            score += nutrients
            
            # Prefer positions far from our current position (spread out!)
            if distance > 10:
                score += 20
            
            # Slight penalty for very far distances (still want to get there eventually)
            score -= distance * 0.3
            
            if score > best_score:
                best_score = score
                best_position = Position(x=x, y=y)
        
        return best_position