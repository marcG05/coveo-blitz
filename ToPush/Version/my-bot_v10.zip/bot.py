import random
from game_message import *


class Bot:
    def __init__(self):
        self.spawner_line_positions = []  # Track target positions for spawners
        self.spawner_line_created = False
        self.spores_assigned_to_spawners = set()  # Track which spores are going to create spawners

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        SPAWNER LINE STRATEGY: Create a line of spawners across the map and pump massive nutrients into them.
        Focus on spawner production over spore movement.
        """
        actions = []
        my_team: TeamInfo = game_message.world.teamInfos[game_message.yourTeamId]
        game_map = game_message.world.map
        
        print(f"Tick {game_message.tick}: Nutrients: {my_team.nutrients}, Spores: {len(my_team.spores)}, Spawners: {len(my_team.spawners)}, Next Spawner Cost: {my_team.nextSpawnerCost}")
        
        # CRITICAL: Create initial spawner if we have zero spawners!
        if len(my_team.spawners) == 0 and len(my_team.spores) > 0:
            # Create spawner from the first spore immediately
            actions.append(SporeCreateSpawnerAction(sporeId=my_team.spores[0].id))
            return actions  # Return immediately to create the spawner
        
        # Initialize spawner line positions on first run
        if not self.spawner_line_created:
            self._create_spawner_line_plan(game_map)
            self.spawner_line_created = True
        
        # Step 1: Produce spores from ALL spawners
        # After tick 500: Create ATTACK spores to destroy enemy spawners!
        max_biomass = 100 if game_message.tick < 500 else 200  # After 500, allow attack spores
        
        # After tick 500, create some heavy attack spores
        attack_mode = game_message.tick >= 500
        
        # Prioritize creating MANY spores rather than few heavy ones
        for spawner in my_team.spawners:
            # After tick 500, occasionally create ATTACK spores (150-200 biomass)
            if attack_mode and my_team.nutrients >= 150 and len(my_team.spores) < 15:
                # Create attack spore with 150-200 biomass to destroy enemy spawners
                attack_biomass = min(200, my_team.nutrients)
                if attack_biomass >= 150:
                    actions.append(
                        SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=attack_biomass)
                    )
                    my_team.nutrients -= attack_biomass
                    continue  # Only one attack spore per spawner per turn
            
            # Always try to produce at least one spore per spawner if we have nutrients
            if my_team.nutrients >= 25:
                # Light spores for exploration and combat (25-40 biomass)
                if my_team.nutrients >= 100:
                    # We're rich - create multiple spores
                    biomass = 30  # Light and fast
                elif my_team.nutrients >= 50:
                    biomass = 30
                elif my_team.nutrients >= 25:
                    biomass = 25
                else:
                    continue
                
                actions.append(
                    SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=biomass)
                )
                my_team.nutrients -= biomass
            
            # If we still have lots of nutrients, produce another spore for spawner building (before tick 500)
            if not attack_mode and my_team.nutrients >= 80 and len(my_team.spawners) < 10:
                spawner_biomass = min(80, my_team.nutrients)
                actions.append(
                    SpawnerProduceSporeAction(spawnerId=spawner.id, biomass=spawner_biomass)
                )
                my_team.nutrients -= spawner_biomass
        
        # Step 2: Convert spores to spawners ONLY if we really need more spawners
        target_spawner_count = min(8, len(self.spawner_line_positions))  # Reduced from 15 to 8 spawners max
        
        for spore in my_team.spores[:]:  # Use slice to avoid modifying list during iteration
            if len(my_team.spawners) >= target_spawner_count:
                break  # We have enough spawners - focus on exploration!
            
            # Only create spawners from spores with 80+ biomass
            if spore.biomass >= 80 and spore.biomass >= my_team.nextSpawnerCost:
                # Check if there's already a spawner at this exact position
                spawner_at_position = False
                for spawner in my_team.spawners:
                    if spawner.position.x == spore.position.x and spawner.position.y == spore.position.y:
                        spawner_at_position = True
                        break
                
                if spawner_at_position:
                    # This spore is at a spawner, don't try to create another one
                    continue
                
                # Find if spore is near a planned spawner position
                near_planned_position = False
                for planned_pos in self.spawner_line_positions:
                    if abs(spore.position.x - planned_pos.x) <= 3 and abs(spore.position.y - planned_pos.y) <= 3:
                        near_planned_position = True
                        break
                
                # Create spawner if near a good position or if we have very few spawners
                if near_planned_position or len(my_team.spawners) < 5:
                    actions.append(SporeCreateSpawnerAction(sporeId=spore.id))
                    self.spores_assigned_to_spawners.add(spore.id)
                    continue  # Skip movement for this spore
        
        # Step 3: Move spores - After tick 500, ALL spores become aggressive!
        attack_mode = game_message.tick >= 500
        
        for spore in my_team.spores:
            if spore.id in self.spores_assigned_to_spawners:
                continue  # This spore is becoming a spawner
            
            # After tick 500: ATTACK MODE - prioritize enemies!
            if attack_mode:
                # Heavy spores (150+ biomass) specifically target enemy SPAWNERS
                if spore.biomass >= 150:
                    target = self._find_enemy_spawner_target(spore, game_message.world, my_team, game_message)
                    
                    actions.append(
                        SporeMoveToAction(
                            sporeId=spore.id,
                            position=target
                        )
                    )
                    
                else:
                    # Light spores attack enemy TERRITORY and spores
                    target = self._find_enemy_target(spore, game_message.world, my_team, game_message)
                    
                    actions.append(
                        SporeMoveToAction(
                            sporeId=spore.id,
                            position=target
                        )
                    )
                    
                   
            # Before tick 500: Heavy spores build spawners, light spores explore
            elif spore.biomass >= 70 and len(my_team.spawners) < target_spawner_count:
                # Heavy spore - move to spawner positions (only if we need more spawners)
                target = self._find_best_spawner_position(spore, my_team, game_map, game_message.world)
                
                actions.append(
                    SporeMoveToAction(
                        sporeId=spore.id,
                        position=target
                    )
                )
                

            else:
                # ALL other spores - EXPLORE AND CONQUER!
                target = self._find_exploration_target(spore, game_map, game_message.world, my_team, game_message)
                
                actions.append(
                    SporeMoveToAction(
                        sporeId=spore.id,
                        position=target
                    )
                )
                

        
        return actions
    
    def _create_spawner_line_plan(self, game_map: GameMap):
        """
        Plan spawner positions in a line across the map.
        Creates positions on both sides (left and right edges).
        """
        print("Creating spawner line plan...")
        
        # Create spawners along the left edge (x = 10% of map width)
        left_x = max(2, game_map.width // 10)
        # Create spawners along the right edge (x = 90% of map width)
        right_x = min(game_map.width - 3, (game_map.width * 9) // 10)
        # Create spawners along the middle
        middle_x = game_map.width // 2
        
        # Space spawners evenly along Y axis
        spacing = max(3, game_map.height // 8)  # About 8 spawners per line
        
        for y in range(spacing // 2, game_map.height, spacing):
            # Left side spawner
            self.spawner_line_positions.append(Position(x=left_x, y=y))
            # Middle spawner
            self.spawner_line_positions.append(Position(x=middle_x, y=y))
            # Right side spawner
            self.spawner_line_positions.append(Position(x=right_x, y=y))
        
    
    def _find_best_spawner_position(self, spore: Spore, my_team: TeamInfo, game_map: GameMap, world: GameWorld) -> Position:
        """
        Find the best position for a spore to move toward to eventually create a spawner.
        Prioritizes high-nutrient areas along the spawner line.
        """
        best_score = -999999
        best_position = self.spawner_line_positions[0] if self.spawner_line_positions else Position(x=game_map.width // 2, y=game_map.height // 2)
        
        # Check each planned spawner position
        for pos in self.spawner_line_positions:
            # Skip if there's already a spawner very close
            too_close_to_existing = False
            for spawner in my_team.spawners:
                if abs(spawner.position.x - pos.x) <= 2 and abs(spawner.position.y - pos.y) <= 2:
                    too_close_to_existing = True
                    break
            
            if too_close_to_existing:
                continue
            
            # Calculate score based on:
            # 1. Distance from spore (prefer closer)
            # 2. Nutrient value at that position
            # 3. Whether it's not owned by us yet
            
            distance = abs(spore.position.x - pos.x) + abs(spore.position.y - pos.y)
            
            # Ensure position is within bounds
            safe_x = max(0, min(pos.x, game_map.width - 1))
            safe_y = max(0, min(pos.y, game_map.height - 1))
            
            nutrients = game_map.nutrientGrid[safe_y][safe_x]
            owner = world.ownershipGrid[safe_y][safe_x]
            
            score = -distance * 2  # Prefer closer positions
            score += nutrients * 10  # HEAVILY prioritize high-nutrient tiles
            
            # Bonus for unowned territory
            if owner != spore.teamId:
                score += 50
            
            if score > best_score:
                best_score = score
                best_position = Position(x=safe_x, y=safe_y)
        
        return best_position
    
    def _find_exploration_target(self, spore: Spore, game_map: GameMap, world: GameWorld, my_team: TeamInfo, game_message: TeamGameState) -> Position:
        """
        Find exploration targets for spores to claim territory and CONQUER ENEMIES!
        Prioritizes enemy territory and high-nutrient tiles.
        """
        best_score = -999999
        best_position = Position(
            x=random.randint(0, game_map.width - 1),
            y=random.randint(0, game_map.height - 1)
        )
        
        # Sample MORE positions to find better targets (20 instead of 15)
        for _ in range(20):
            x = random.randint(0, game_map.width - 1)
            y = random.randint(0, game_map.height - 1)
            
            nutrients = game_map.nutrientGrid[y][x]
            distance = abs(spore.position.x - x) + abs(spore.position.y - y)
            owner = world.ownershipGrid[y][x]
            current_biomass = world.biomassGrid[y][x]
            
            # Score calculation - AGGRESSIVE!
            score = nutrients * 8  # Nutrients are very valuable
            score -= distance * 1.0  # Prefer closer tiles but willing to travel far
            
            # HEAVILY prefer enemy territory over neutral
            if owner != spore.teamId and owner != game_message.constants.neutralTeamId:
                score += 100  # HUGE bonus for enemy tiles - ATTACK!
            elif owner == game_message.constants.neutralTeamId:
                score += 50  # Still good bonus for neutral tiles
            
            # Prefer tiles we can conquer (low biomass or we have more)
            if current_biomass < spore.biomass:
                score += 40  # We can win this fight!
            
            # Bonus for high-value targets
            if nutrients >= 3:
                score += 30  # High nutrient tiles are worth fighting for
            
            # Don't waste time too close to our spawners (let them handle local area)
            too_close_to_spawner = False
            for spawner in my_team.spawners:
                if abs(spawner.position.x - x) <= 3 and abs(spawner.position.y - y) <= 3:
                    too_close_to_spawner = True
                    break
            
            if too_close_to_spawner:
                score -= 30  # Small penalty, not huge
            
            if score > best_score:
                best_score = score
                best_position = Position(x=x, y=y)
        
        return best_position
    
    def _find_enemy_spawner_target(self, spore: Spore, world: GameWorld, my_team: TeamInfo, game_message: TeamGameState) -> Position:
        """
        Find enemy spawners to attack and destroy! (After tick 500)
        Only send spores with 150-200 biomass to attack.
        """
        best_score = -999999
        best_target = Position(x=spore.position.x, y=spore.position.y)
        
        # Look for all enemy spawners
        enemy_spawners = []
        for spawner in world.spawners:
            if spawner.teamId != my_team.teamId and spawner.teamId != game_message.constants.neutralTeamId:
                enemy_spawners.append(spawner)
        
        if len(enemy_spawners) == 0:
            # No enemy spawners found - just explore
            return self._find_exploration_target(spore, world.map, world, my_team, game_message)
        
        # Evaluate each enemy spawner
        for enemy_spawner in enemy_spawners:
            distance = abs(spore.position.x - enemy_spawner.position.x) + abs(spore.position.y - enemy_spawner.position.y)
            
            # Check the biomass at the spawner position
            spawner_biomass = world.biomassGrid[enemy_spawner.position.y][enemy_spawner.position.x]
            
            # Score calculation
            score = 0
            
            # HUGE bonus for enemy spawners - this is our target!
            score += 500
            
            # Prefer closer spawners
            score -= distance * 2
            
            # Only attack if we have enough biomass (don't send more than 200)
            if spore.biomass >= spawner_biomass:
                score += 200  # We can win this fight!
            elif spore.biomass >= spawner_biomass * 0.8:
                score += 100  # Close fight, but worth it
            else:
                score -= 300  # Too risky
            
            # Prefer spawners with less biomass (easier to conquer)
            score -= spawner_biomass * 0.5
            
            if score > best_score:
                best_score = score
                best_target = enemy_spawner.position
        
        return best_target
    
    def _find_enemy_target(self, spore: Spore, world: GameWorld, my_team: TeamInfo, game_message: TeamGameState) -> Position:
        """
        Find enemy territory, spores, or any enemy assets to attack!
        Used by light spores after tick 500.
        """
        best_score = -999999
        best_target = Position(x=spore.position.x, y=spore.position.y)
        
        # First, look for enemy SPORES nearby
        enemy_spores = []
        for enemy_spore in world.spores:
            if enemy_spore.teamId != my_team.teamId and enemy_spore.teamId != game_message.constants.neutralTeamId:
                enemy_spores.append(enemy_spore)
        
        # Target enemy spores if we can beat them
        for enemy_spore in enemy_spores:
            distance = abs(spore.position.x - enemy_spore.position.x) + abs(spore.position.y - enemy_spore.position.y)
            
            # Only consider nearby enemies (within 15 tiles)
            if distance > 15:
                continue
            
            score = 0
            
            # Bonus for targeting enemy spores
            score += 300
            
            # Prefer closer enemies
            score -= distance * 3
            
            # Only attack if we can win
            if spore.biomass > enemy_spore.biomass:
                score += 250  # We can destroy them!
            elif spore.biomass >= enemy_spore.biomass * 0.9:
                score += 100  # Close fight
            else:
                score -= 500  # Don't attack, we'll lose
            
            if score > best_score:
                best_score = score
                best_target = enemy_spore.position
        
        # If no good spore targets, look for enemy TERRITORY with high biomass
        if best_score < 100:
            # Sample enemy territory positions
            for _ in range(25):
                x = random.randint(0, world.map.width - 1)
                y = random.randint(0, world.map.height - 1)
                
                owner = world.ownershipGrid[y][x]
                
                # Only target enemy-owned tiles
                if owner == my_team.teamId or owner == game_message.constants.neutralTeamId:
                    continue
                
                biomass = world.biomassGrid[y][x]
                nutrients = world.map.nutrientGrid[y][x]
                distance = abs(spore.position.x - x) + abs(spore.position.y - y)
                
                score = 0
                
                # ATTACK enemy territory!
                score += 200
                
                # Prefer high-value enemy tiles
                score += biomass * 2  # More biomass = more valuable
                score += nutrients * 10  # High nutrient tiles
                
                # Prefer closer tiles
                score -= distance * 1.5
                
                # Prefer tiles we can conquer
                if spore.biomass > biomass:
                    score += 150
                
                if score > best_score:
                    best_score = score
                    best_target = Position(x=x, y=y)
        
        # If still no good target, fall back to exploration
        if best_score < 0:
            return self._find_exploration_target(spore, world.map, world, my_team, game_message)
        
        return best_target
